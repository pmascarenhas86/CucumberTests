package cucumberTests.dataProvider;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import org.apache.commons.lang3.StringUtils;


public class ConfigFileReader {

	private static Properties properties;
	private final String propertyFilePath= "config//config.properties";


	public ConfigFileReader(){
		BufferedReader reader;
		try {
			reader = new BufferedReader(new FileReader(propertyFilePath));
			properties = new Properties();
			try {
				properties.load(reader);
				reader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			throw new RuntimeException("Arquivo PROPERTIES nao esta na pasta especificada: " + propertyFilePath);
		}
	}

	public static String getDriverPath(){
		String driverPath = properties.getProperty("driverPath");
		if(driverPath!= null) return driverPath;
		else throw new RuntimeException("driverPath nao localizada no arquivo config.properties.");
	}

	public static String getDriverType(){
		String driverType = properties.getProperty("driverType");
		if(driverType!= null) return driverType;
		else throw new RuntimeException("driverType nao localizado no arquivo config.properties.");
	}


	public long getImplicitlyWait() {
		String implicitlyWait = properties.getProperty("implicitlyWait");
		if(implicitlyWait != null) return Long.parseLong(implicitlyWait);
		else throw new RuntimeException("implicitlyWaitnao localizado no arquivo config.properties.");
	}

	public static String getApplicationUrlClearing() {
		String URLClearing = properties.getProperty("URLClearing");
		if(URLClearing != null) return URLClearing;
		else throw new RuntimeException("URLClearing nao localizada no arquivo config.properties.");
	}

	public static  String getApplicationUrlPricing() {
		String urlPricing = properties.getProperty("URLPricing");
		if(urlPricing != null) return urlPricing;
		else throw new RuntimeException("URLPricing nao localizada no arquivo config.properties.");
	}

	public static String getApplicationUser() {
		String username = properties.getProperty("USERNAME");
		if(username != null) return username;
		else throw new RuntimeException("Login de testes nao identificado no arquivo config.properties");
	}

	public static String getApplicationUserPass() {
		String pass = properties.getProperty("PASS");
		if(pass != null) return pass;
		else throw new RuntimeException("Senha do usuario de testes nao identificada no arquivo config.properties.");
	}

	public static String getDatabasePath(){
		String DatabasePath = properties.getProperty("DatabasePath");
			if(DatabasePath!= null) return DatabasePath;
		else
		throw new RuntimeException("Pasta que contem BD de Massa de Dados nao localizada no arquivo config.properties.");
	}

	public static String getPuMedioDB(){
		String puMedio = properties.getProperty("MassaPUMedio");
			if(puMedio!= null) return puMedio;
		else
		throw new RuntimeException("Massa para PU medio indisponivel");
	}

	public static String getEcIndicDB(){
		String MassaIE = properties.getProperty("IndicadoresEconomicos");
			if(MassaIE!= null) return MassaIE;
		else
		throw new RuntimeException("Massa para Indic. Econom. indisponivel");
	}

	public static String getCurvesIndicDB(){
		String MassaIC = properties.getProperty("IndicadoresCurvas");
			if(MassaIC!= null) return MassaIC;
		else
		throw new RuntimeException("Massa para Indic. de Curvas indisponivel");
	}

public void validaProperties() {
	int w = 110;

	System.out.println(StringUtils.rightPad("+", w - 1, "-") + "+");
	System.out.println(StringUtils.center(StringUtils.center("VALIDANDO ARQUIVO DE CONFIGURACOES", w - 2), w, "|"));
	System.out.println(StringUtils.rightPad("+", w - 1, "-") + "+");
	System.out.println(StringUtils.center(StringUtils.center("Driver path: "+getDriverPath(), w - 2), w, "|"));
	System.out.println(StringUtils.center(StringUtils.center("Driver Tipo: " +getDriverType(), w - 2), w, "|"));
	System.out.println(StringUtils.center(StringUtils.center("TimeOut: "+getImplicitlyWait()+ " segundos", w - 2), w, "|"));
	System.out.println(StringUtils.center(StringUtils.center("URLClearing: "+getApplicationUrlClearing(), w - 2), w, "|"));
	System.out.println(StringUtils.center(StringUtils.center("URLPricing: "+getApplicationUrlPricing(), w - 2), w, "|"));
	System.out.println(StringUtils.center(StringUtils.center("Usuario: "+getApplicationUser(), w - 2), w, "|"));
	System.out.println(StringUtils.center(StringUtils.center("Senha: "+replaceAll(getApplicationUserPass(), "SENHA_DO_USUARIO"), w - 2), w, "|"));
	System.out.println(StringUtils.rightPad("+", w - 1, "-") + "+");
	System.out.println(StringUtils.center(StringUtils.center("VALIDANDO ARQUIVO DE MASSAS", w - 2), w, "|"));
	System.out.println(StringUtils.rightPad("+", w - 1, "-") + "+");
	System.out.println(StringUtils.center(StringUtils.center("Pasta Massa de Dados ==> "+getDatabasePath(), w - 2), w, "|"));
	System.out.println(StringUtils.center(StringUtils.center("Massa PU Medio ==> "+getPuMedioDB(), w - 2), w, "|"));
	System.out.println(StringUtils.center(StringUtils.center("Indicadores Economicos ==> "+getEcIndicDB(), w - 2), w, "|"));
	System.out.println(StringUtils.center(StringUtils.center("Indicadores de Curvas ==> "+getCurvesIndicDB(), w - 2), w, "|"));
	System.out.println(StringUtils.rightPad("+", w - 1, "-") + "+");
	System.out.println(StringUtils.center(StringUtils.center("FIM DAS VALIDACOES", w - 2), w, "|"));
	System.out.println(StringUtils.rightPad("+", w - 1, "-") + "+");

	System.out.println(StringUtils.rightPad("+", w - 1, "-") + "+");
	System.out.println(StringUtils.center(StringUtils.center("INICIANDO AUTOMACAO", w - 2), w, "|"));
	System.out.println(StringUtils.rightPad("+", w - 1, "-") + "+");
}

private String replaceAll(String applicationUserPass, String string) {
	return "Informacao protegida";
}

public String getReportConfigPath(){
	String reportConfigPath = properties.getProperty("reportConfigPath");
	if(reportConfigPath!= null) return reportConfigPath;
	else throw new RuntimeException("Report Config Path not specified in the Configuration.properties file for the Key:reportConfigPath");		
}


}