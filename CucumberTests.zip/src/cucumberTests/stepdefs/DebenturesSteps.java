package cucumberTests.stepdefs;

import java.io.File;
import java.util.concurrent.TimeUnit;

import org.junit.AfterClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import com.cucumber.listener.Reporter;

import cucumberTests.dataProvider.ConfigFileReader;
import cucumberTests.pageObjects.Clearing.GpsClearingHomePO;
import cucumberTests.pageObjects.Clearing.ImportacaoDeTaxasPO;
import cucumberTests.pageObjects.Clearing.LoginPageClearingPO;
import cucumberTests.pageObjects.Clearing.ManterCurvasPO;
import cucumberTests.pageObjects.Clearing.ManutencaoCurvasTeoricasPO;
import cucumberTests.pageObjects.Clearing.RendaFixaBalcaoPO;
import cucumberTests.pageObjects.Pricing.AnaliseCurvasSpreadPO;
import cucumberTests.pageObjects.Pricing.ConfiguraCurvasPricingPO;
import cucumberTests.pageObjects.Pricing.GpsPricingHomePO;
import cucumberTests.pageObjects.Pricing.LoginPagePricingPO;
import cucumberTests.pageObjects.Pricing.ManterCurvasNovaPO;
import cucumberTests.pageObjects.Pricing.PuMedioPO;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.pt.Dado;
import io.cucumber.java.pt.E;
import io.cucumber.java.pt.Entao;
import io.cucumber.java.pt.Quando;

public class DebenturesSteps{
    WebDriver driver;
    LoginPageClearingPO loginClearing;
    GpsClearingHomePO clearingHome;
    LoginPagePricingPO loginPricing;
	GpsPricingHomePO gpsPricingHome ;
	ConfiguraCurvasPricingPO configurarCurvasPricing;
	ManterCurvasNovaPO	manterCurvasPricing;
	ConfiguraCurvasPricingPO configuraCurvasPricing;
	RendaFixaBalcaoPO rendaFixaBalcao;
	ImportacaoDeTaxasPO importarInsumos;
	PuMedioPO puMedio;
	AnaliseCurvasSpreadPO analisarCurvasSpread;
ManutencaoCurvasTeoricasPO manterCurvasTeoricas;
ConfigFileReader configFileReader;

@Dado("que esteja com o browser aberto")
public void que_esteja_com_o_browser_aberto() {
	configFileReader= new ConfigFileReader();
  	System.setProperty(ConfigFileReader.getDriverType(),ConfigFileReader.getDriverPath());
   	driver=new ChromeDriver();
    driver.manage().timeouts().implicitlyWait(configFileReader.getImplicitlyWait(), TimeUnit.SECONDS);
    driver.manage().window().maximize();
	assert(driver.getTitle()!=null);
    }

@E("que o usuario seja autenticado com sucesso na clearing")
	public void realizarLoginNaClearing() throws Exception {
	loginClearing = new LoginPageClearingPO(driver);
	loginClearing.realizarLoginPadrao(ConfigFileReader.getApplicationUrlClearing());
}

@Quando("escolher Manter Curvas do Menu Curvas")
public void acessandoManterCurvas() throws Exception {
	clearingHome=new GpsClearingHomePO(driver) ;
	clearingHome.AcessaManterCurvas();
	}

@Quando("escolher Manter Curvas Teoricas do Menu Curvas")
public void escolher_manter_curvas_teoricas_do_menu_curvas() throws Exception {
    clearingHome = new GpsClearingHomePO(driver);
    clearingHome.AcessaManutencaoCurvasTeoricas();
}

@E("selecionar {string} no combo de GERACAO")
public void selecionar_no_combo_de_geracao(String GERACAO) {
	manterCurvasTeoricas = new ManutencaoCurvasTeoricasPO(driver);
	manterCurvasTeoricas.comboBoxGeracao.selectByVisibleText(GERACAO);

}

@E("selecionar {string} no combo de STATUS")
public void selecionar_no_combo_de_status(String STATUS) {
	manterCurvasTeoricas.comboBoxStatus.selectByVisibleText(STATUS);
}

@E("selecionar {string} no combo de GRUPO")
public void selecionar_no_combo_de_grupo(String GRUPO) {
	manterCurvasTeoricas.comboBoxGrupo.selectByVisibleText(GRUPO);
}
@E("escolher {string} na listagem de Curva")
public void escolher_na_listagem_de_curva(String Curva) {
	new Select(manterCurvasTeoricas.listagemCurvas).selectByVisibleText(Curva);
}
@E("selecionar {string} no combo de REFERENCIA")
public void selecionar_no_combo_de_referencia(String REFERENCIA) {
	new Select(manterCurvasTeoricas.cboReferencia).selectByVisibleText(REFERENCIA);
}

@E("pressionar o botao Consultar")
public void pressionar_o_botao_consultar() {
	manterCurvasTeoricas.botaoConfirmaComboboxes.click();
}

@Entao("o Modelo de Curva {string} deve existir na tabela")
public void o_modelo_de_curva_deve_existir_na_tabela(String Curva) {
	manterCurvasTeoricas.ValidaCalculos(Curva);
}

@E("configure as curvas conforme arquivo base")
public void ConfiguraViaCSV() throws Exception {
	ManterCurvasPO mcc=new ManterCurvasPO(driver);
	mcc.ManterCurvasViaCSV();
		}

@E("as curvas estarao configuradas com sucesso")
public void curvasCOnfiguradasComSucesso() {
	driver.findElement(By.id("groupCurve")).isDisplayed();
	}

@Dado("que o usuario seja autenticado com sucesso na Pricing")
public void login_pricing_com_sucesso() throws Exception {
	loginPricing=new LoginPagePricingPO(driver);
	loginPricing.realizarLoginPadrao(ConfigFileReader.getApplicationUrlPricing());
}

@Quando("selecionar a opcao ManterCurvas do menu Curvas Spread")
	public void eu_selecionar_a_opcao_manter_curvas_do_menu_curvas_spread() throws Exception {
		gpsPricingHome = new GpsPricingHomePO(driver);
		gpsPricingHome.acessaMenuManterCurvas();
		}

@Entao ("a lista de curvas sera exibida")
public void o_modelo_de_curva_deve_existir_na_tabela() {
	manterCurvasPricing= new ManterCurvasNovaPO(driver);
	assert(manterCurvasPricing.Tabela.isDisplayed());
	}

@Quando("clicar em Editar na curva {string}")
public void clicar_em_editar_na_curva(String Curva) throws InterruptedException {
	manterCurvasPricing.ConsultaTabela(Curva);
	}

@E("selecionar {string} no combobox Modelo")
public void selecionar_theorical(String Modelo) throws InterruptedException {
	configurarCurvasPricing=new ConfiguraCurvasPricingPO(driver);
	configurarCurvasPricing.defineValorComboBox(configurarCurvasPricing.comboBoxModoCalculo,Modelo);
	}

@E("digitar {string} no campo ValorMin")
public void eu_digite_no_campo_valor_min(String ValorMin) {
	configurarCurvasPricing.txtVlrMin.clear();
	configurarCurvasPricing.digitar(ValorMin,configurarCurvasPricing.txtVlrMin);
	}

@E("digitar {string} no campo Penalty")
public void digitar_no_campo_penalty(String Penalty) {
	configurarCurvasPricing.txtPenalty.clear();
	configurarCurvasPricing.digitar(Penalty,configurarCurvasPricing.txtPenalty);
	}

@E("digitar {string} no campo OutlierStatistics")
public void digitar_no_campo_outlier_statistics(String OutlierStatistics) {
	configurarCurvasPricing.txtOutlierStatistics.clear();
	configurarCurvasPricing.digitar(OutlierStatistics,configurarCurvasPricing.txtOutlierStatistics);
	}

@E("escolher {string} no campo OutlierRounds")
public void digitar_no_campo_outlier_rounds(String OutlierRounds) {
	configurarCurvasPricing.escolherQuantidadeRodadas(OutlierRounds);
	}

@E("digitar {string} no campo UpperBoundBeta")
public void digitar_no_campo_upper_bound_beta(String UpperBoundBeta) {
	configurarCurvasPricing.txtUpperBoundBeta.clear();
	configurarCurvasPricing.txtUpperBoundBeta.sendKeys(UpperBoundBeta);
	}

@E("digitar {string} no campo UpperBoundBeta_cred")
public void digitar_no_campo_upper_bound_beta_cred(String UpperBoundBeta_Cred) {
	configurarCurvasPricing.txtUpperBoundBeta_Cred.clear();
	configurarCurvasPricing.txtUpperBoundBeta_Cred.sendKeys(UpperBoundBeta_Cred);
	}

@E("digitar {string} no campo UpperBoundLambda")
public void digitar_no_campo_upper_bound_lambda(String UpperBoundLambda) {
	configurarCurvasPricing.txtUpperBoundLambda.clear();
	configurarCurvasPricing.txtUpperBoundLambda.sendKeys(UpperBoundLambda);
	}

@E("digitar {string} no campo LowerBoundBeta")
public void digitar_no_campo_lower_bound_beta(String LowerBoundBeta) {
	configurarCurvasPricing.txtUpperBoundLambda.clear();
	configurarCurvasPricing.txtLowerBoundBeta.sendKeys(LowerBoundBeta);
	}

@E("digitar {string} no campo LowerBoundBeta_cred")
public void digitar_no_campo_lower_bound_beta_cred(String LowerBoundBeta_Cred) {
	configurarCurvasPricing.txtLowerBoundBeta_Cred.clear();
	configurarCurvasPricing.txtLowerBoundBeta_Cred.sendKeys(LowerBoundBeta_Cred);
	}

@E("digitar {string} no campo LowerBoundLambda")
public void digitar_no_campo_lower_bound_lambda(String LowerBoundLambda) {
	configurarCurvasPricing.txtLowerBoundLambda.clear();
	configurarCurvasPricing.txtLowerBoundLambda.sendKeys(LowerBoundLambda);
	}


@Quando("escolher {string} no combo AddingCurve")
public void escolher_no_combo_adding_curve(String AddingCurve) throws InterruptedException {
	configurarCurvasPricing.escolherCurvaAdding(AddingCurve);
	}


@E("digitar {string} no campo AddingValue")
public void eu_digite_no_campo_adding_value(String AddingValue) {
	configurarCurvasPricing.txtAddingValue.clear();
	configurarCurvasPricing.txtAddingValue.sendKeys(AddingValue);
	}

@E("digitar {string} no campo Beta")
public void eu_digite_no_campo_beta(String Beta) {
	configurarCurvasPricing.txtBeta.clear();
	configurarCurvasPricing.digitar(Beta, configurarCurvasPricing.txtBeta);
	}

@E("digitar {string} no campo Beta_cred")
public void eu_digite_no_campo_beta_cred(String Beta_cred) {
	configurarCurvasPricing.txtBeta_Cred.clear();
	configurarCurvasPricing.txtBeta_Cred.sendKeys(Beta_cred);
	}

@E("digitar {string} no campo Lambda")
public void eu_digite_no_campo_lambda(String Lambda) {
	configurarCurvasPricing.txtLambda.clear();
	configurarCurvasPricing.digitar(Lambda, configurarCurvasPricing.txtLambda);
	}

@E("pressionar o botao Salvar confirmando a alteracao,")
public void salvar_configuracao_curva() throws Throwable {
	configurarCurvasPricing.botaoSalvar.click();
	configurarCurvasPricing.botaoConfirmaAlteracao.click();
	configurarCurvasPricing.popUpConfirmacao.isDisplayed();
	configurarCurvasPricing.popUpConfirmacao.click();
	}

@E("acesse a opcao Manter Pu medio do menu RendaFixa")
public void acessa_tela_pu_medio() throws Exception {
	gpsPricingHome = new GpsPricingHomePO(driver);
	puMedio=new PuMedioPO(driver);
	gpsPricingHome.AcessaManterPUMedio();
	Thread.sleep(2000);
	 }

@Entao("o texto Manter PU Medio deve ser exibido")
public void valida_tela_pu_medio(){
	puMedio.Valida(puMedio.botaoImportar);
	}

@Quando("selecionar o arquivo para envio")
public void carrega_anexo() throws Exception{
	File file = new File(new File(ConfigFileReader.getPuMedioDB()).getAbsolutePath());
	puMedio.EnviaPUMedio(file.toString());
	Thread.sleep(3000);
	}

@E("clicar em importar")
public void clicar_importar(){
	puMedio.botaoImportar.click();
	}

@Quando("o arquivo foi importado")
public void valida_acao(){
	puMedio.TabelaPu.isDisplayed();
	}

@E("clicar em salvar")
public void salvar_puMedio() throws Exception{
	}


@Entao("realizara o logout da Clearing")
public void logout_Clearing() {
	clearingHome=new GpsClearingHomePO(driver) ;
	clearingHome.encerraSessao();
		}

//Pricing
@Entao("realizara o logout da Pricing")
public void logout_Pricing() {
	gpsPricingHome.botaoLogout.click();
   }

@E("encerra o navegador")
public void encerraNavegador() {
	driver.close();
	driver.quit();
   }

@E("haja Debentures ativas no ambiente")
public void haja_debentures_ativas_no_ambiente() {
	clearingHome=new GpsClearingHomePO(driver) ;
	clearingHome.AcessaManterRendaFixaBalcao();
	}

@Entao("o usuario deve importar a planilha de insumos de Curvas e Indicadoes")
public void o_usuario_deve_importar_a_planilha_de_insumos_de_curvas_e_indicadoes() throws InterruptedException {
	clearingHome=new GpsClearingHomePO(driver) ;
	clearingHome.AcessaFerramentasImportarInsumos();
	importarInsumos= new ImportacaoDeTaxasPO(driver);
	importarInsumos.importarPlanilhaDeCurvas();
	importarInsumos.importarPlanilhaDeIndicadores();
	}


@Entao("configurar as curvas incentivadas e Nao Incentivadas")
public void configurar_as_curvas_incentivadas_e_nao_incentivadas() throws Throwable {
	ConfiguraViaCSV();
	}

@Dado("que realize o calculo e publicacao")
public void que_realize_o_calculo_e_publicacao() throws InterruptedException {
	driver.get("https://bbelt.qa2.intraservice.corp/PricingWeb/curvesCalculation");
	Thread.sleep(10000);
	}

@Dado("ao acessar novamente a Clearing")
public void ao_acessar_novamente_a_clearing() {
}

@Entao("as debentures serão exibidas na opcao Manter Renda Fixa Balcao")
public void as_debentures_serão_exibidas_na_opcao_manter_renda_fixa_balcao() {
	clearingHome=new GpsClearingHomePO(driver) ;
	clearingHome.AcessaManterRendaFixaBalcao();
	rendaFixaBalcao= new RendaFixaBalcaoPO(driver);
	rendaFixaBalcao.tabelaDebenturesResult.isDisplayed();
}


@Quando ("selecionar a opcao AnalisarCurvas do menu Curvas Spread")
public void analisarCurvasSpread() {
	gpsPricingHome = new GpsPricingHomePO(driver);
	analisarCurvasSpread=new AnaliseCurvasSpreadPO(driver);
	gpsPricingHome.AcessaAnalisarCurvas();
}

@Quando("localizar a {string}, realizar o Calculo e se necessario a Publicacao")
public void localizar_a_realizar_o_calculo_e_se_necessßrio_a_publicacao(String Curva) throws InterruptedException {
analisarCurvasSpread.calculaEPublicaPorCurva(Curva);
}

@Entao("validara o calculo do Premio do PU")
public void validara_o_calculo_do_premio_do_pu() throws Throwable {
		gpsPricingHome = new GpsPricingHomePO(driver);
		analisarCurvasSpread=new AnaliseCurvasSpreadPO(driver);
		gpsPricingHome.AcessaManterPremio();
	}


@Before
public void validaArquivoConfig() throws Exception, Exception
{configFileReader= new ConfigFileReader();
configFileReader.validaProperties();
}
/*
@After
public static void report()
{
Reporter.loadXMLConfig(new File("config/extent-config.xml"));
Reporter.setSystemInfo("OS User", System.getProperty("user.name"));
Reporter.setSystemInfo("Application Username", "");
Reporter.setSystemInfo("Application Name", "Test App ");
Reporter.setSystemInfo("Operating System Type", System.getProperty("os.name").toString());
Reporter.setSystemInfo("Environment", "Production");
Reporter.setTestRunnerOutput("Debentures Test Execution Cucumber Report");
}
*/

}