package cucumberTests;

import org.junit.runner.RunWith;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(
plugin = { "pretty", "html:reports/cucumber-reports.html" },

features="src/resources/features",
tags="@testeCucumber",
glue = {"cucumberTests.stepdefs"},
monochrome = true, dryRun = false)

public class cucumberRunner {

	public static void main(String[] args) {


	}

}
