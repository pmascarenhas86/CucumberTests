package cucumberTests.pageObjects;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Base {

protected WebDriver driver;

	protected Base(WebDriver driver) {
	this.driver = driver;
		}


	public static void abreProperties() {
		try(InputStream input = Base.class.getClassLoader().getResourceAsStream("config.properties")){
			Properties prop = new Properties();
			if (input==null) {
				System.out.println("Falta arquivo Properties");
				return;
			}
			prop.load(input);
			System.out.println(prop.getProperty("test.LOGIN"));
		//	final String LOGIN = prop.getProperty("test.LOGIN");
			System.out.println(prop.getProperty("test.PASSWORD"));
			System.out.println(prop.getProperty("test.URLClearing"));
			System.out.println(prop.getProperty("test.URLPricing"));
			}
			catch(IOException ex) {
				ex.printStackTrace();}
					}



	//DEFINIR AMBIENTE
		//VARIAVEL PARA IDENTIFICAR O NAVEGADOR
	public static String tipoBrowser="webdriver.chrome.driver";
		//QA2
	public static String URLClearing = "https://bbelt.qa2.intraservice.corp/gps-clearing-web/initialPage/initial.htm";
	public static String URLPricing = "https://bbelt.qa2.intraservice.corp/PricingWeb/";

		//UAT2
	public static String URLUATPricing = "https://bbelt.uat2.internalenv.corp/gpsPricingHome-clearing-web/";
	public static String URLUATClearing = "https://bbelt.uat2.internalenv.corp/gps-clearing-web/initialPage/initial.htm";
	public static String URLDAPFocus="https://bbelt.uat2.internalenv.corp/PricingWebCurves/";

		//VARIAVEIS DE PRINT
	public static String errado = "arguments[0].setAttribute('style', 'background: yellow; border: 3px solid red;');";
	//public static String correto = "arguments[0].setAttribute('style', 'background: yellow; border: 3px solid teal;');";
	public static String correto = "arguments[0].setAttribute('style', 'border: 3px solid teal;');";

	public static final String LOGIN="TEST_TSQATS";
	public static final String PASSWORD = "31tapBrS#h";


	public String obterTextoDoElemento(WebElement element) {
		return element.getText();
	}


	public Boolean visivel(WebElement e) {
		try {
				return e.isDisplayed();
		}
				catch (org.openqa.selenium.NoSuchElementException exc)
		{
			return false;
		}
	}

	public String PegaAtributo(WebDriver driver, String locator, String attribute) {
		WebElement element = driver.findElement(By.xpath(locator));
		return element.getAttribute(attribute);
	}

	public static void takeSnapShot(WebDriver webdriver, String fileWithPath) {
		TakesScreenshot scrShot = ((TakesScreenshot) webdriver);
		File SrcFile = scrShot.getScreenshotAs(OutputType.FILE);
		File DestFile = new File(fileWithPath);
		try {
			FileUtils.copyFile(SrcFile, DestFile);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void digitar(String s, WebElement e) {
		e.sendKeys(s);
	}


	 public void BuscarDentroDaTabelaAngular(WebElement tabelaAlvo,String elementoProcurado) {
		 boolean localizada=false;

			  List<WebElement> linha = tabelaAlvo.findElements(By.className("datatable-body-row"));
				 		 int i=1;
				 		while(!localizada && i<=linha.size()) {
				 			WebElement Curva = driver.findElement(By.xpath("/html/body/app-root/app-list-spread-curve/div/div/main/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper["+i+"]/datatable-body-row/div[2]/datatable-body-cell[1]/div"));
				 			System.out.println("Buscando "+ elementoProcurado);
				 			System.out.println(Curva.getText());
				 			 	if(Curva.getText().equals(elementoProcurado)) {
				 		localizada=true;
				 		     driver.findElement(By.xpath("/html/body/app-root/app-list-spread-curve/div/div/main/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper["+i+"]/datatable-body-row/div[2]/datatable-body-cell[5]/div/button/i")).click();
				 		    			 		    			      }
				 	else {System.out.println(Curva.getText());
				 		i++;}
				 				 }
		 }

	 public void esperarPeloElemento(Integer t,WebElement e) {
	 WebDriverWait wait = new WebDriverWait(driver,t);
	 wait.until(ExpectedConditions.elementToBeClickable(e));
	 }

}




