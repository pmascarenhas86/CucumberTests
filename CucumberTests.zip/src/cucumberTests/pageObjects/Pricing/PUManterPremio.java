package cucumberTests.pageObjects.Pricing;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import cucumberTests.pageObjects.Base;

public class PUManterPremio extends Base{

	protected PUManterPremio(WebDriver driver) {
		super(driver);
		driver=this.driver;
		PageFactory.initElements(driver,this);
	}


	@FindBy(xpath="//input[@id='fileUpload']")
	public WebElement InputArquivo;

	@FindBy(xpath="//button[contains(text(),'Importar')]")
	public WebElement btnImportar;

	@FindBy(xpath="//button[contains(text(),'Exportar')]")
	public WebElement btnExportar;

	@FindBy(xpath="//button[contains(text(),'Calcular')]")
	public WebElement btnCalcular;

	@FindBy(xpath="//body/app-root[1]/app-maintain-premium[1]/div[1]/div[1]/div[1]/main[1]/ngx-datatable[1]")
	public WebElement TabelaManterPremio;

}
