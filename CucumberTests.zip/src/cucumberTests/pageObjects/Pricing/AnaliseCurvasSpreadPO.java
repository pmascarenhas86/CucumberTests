package cucumberTests.pageObjects.Pricing;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumberTests.pageObjects.Base;


public class AnaliseCurvasSpreadPO extends Base {
	JavascriptExecutor js;

public AnaliseCurvasSpreadPO(WebDriver driver) {
	super(driver);
	this.driver=driver;
	this.js = (JavascriptExecutor) this.driver;
	PageFactory.initElements(driver,this);
	}

@FindBy(css="body.bg-light:nth-child(4) app-debentures.ng-star-inserted:nth-child(2) div.container-fluid:nth-child(3) div.row.min-vh-100 main.col.px-0 div.ng-star-inserted:nth-child(1) ngb-accordion.accordion div.card.ng-star-inserted div.card-header div.row.panel-header.ng-star-inserted div.col-3.pull-right:nth-child(5) div.btn-toolbar.text-center.well > button.btn.btn-sm.btn-outline-secondary.col-xs-2:nth-child(1)")
public WebElement botaoCalcular;

@FindBy(css="body.bg-light:nth-child(4) app-debentures.ng-star-inserted:nth-child(2) div.container-fluid:nth-child(3) div.row.min-vh-100 main.col.px-0 div.ng-star-inserted:nth-child(1) ngb-accordion.accordion div.card.ng-star-inserted div.card-header div.row.panel-header.ng-star-inserted div.col-3.pull-right:nth-child(5) div.btn-toolbar.text-center.well > button.btn.btn-sm.btn-outline-secondary.col-xs-2.margin-left:nth-child(2)")
public WebElement botaoUsarT1;

@FindBy(css="body.bg-light:nth-child(4) app-debentures.ng-star-inserted:nth-child(2) div.container-fluid:nth-child(3) div.row.min-vh-100 main.col.px-0 div.ng-star-inserted:nth-child(1) ngb-accordion.accordion div.card.ng-star-inserted div.card-header div.row.panel-header.ng-star-inserted div.col-3.pull-right:nth-child(5) div.btn-toolbar.text-center.well > button.btn.btn-sm.btn-outline-secondary.col-xs-2.margin-left:nth-child(3)")
public WebElement botaoPublicar;


@FindBy(css="body.bg-light:nth-child(4) app-debentures.ng-star-inserted:nth-child(2) div.container-fluid:nth-child(3) div.row.min-vh-100 main.col.px-0 div.row.sc-card:nth-child(5) div.col-md-2:nth-child(3) > button.btn.btn-primary.float-right")
public WebElement botaoPublicarTodos;

@FindBy(css="body.bg-light:nth-child(4) app-debentures.ng-star-inserted:nth-child(2) div.container-fluid:nth-child(3) div.row.min-vh-100 main.col.px-0 div.ng-star-inserted:nth-child(4) ngb-accordion.accordion div.card.ng-star-inserted div.card-header div.row.panel-header.ng-star-inserted div.col-1:nth-child(4) div:nth-child(2) > img:nth-child(1)")
public WebElement farol;

@FindBy(css="#btn_confirm")
public WebElement btnConfirmaPublicacao;

@FindBy(xpath="//body/app-root[1]/app-debentures[1]/div[1]/div[1]/main[1]")
public WebElement ListagemCurvas;


public void calculaEPublicaPorCurva(String s)  {
	 boolean localizada=false;
	 String s2 = s.replace("YC_", "");
	 List<WebElement> qtdCurvas= ListagemCurvas.findElements(By.tagName("ngb-accordion"));
	 //System.out.println("Buscando: "+s);
		 		 int i=1;
		 		while(!localizada && i<=qtdCurvas.size()) {
		 			WebElement CurvaX = driver.findElement(By.xpath("/html[1]/body[1]/app-root[1]/app-debentures[1]/div[1]/div[1]/main[1]/div["+i+"]/ngb-accordion[1]/div[1]/div[1]/div[1]/div[2]"));
		 				 	if(CurvaX.getText().contains(s2)) {
		 		localizada=true;

	 			//Calcular

//System.out.println("Pressionei o botao "+ driver.findElement(By.xpath("/html[1]/body[1]/app-root[1]/app-debentures[1]/div[1]/div[1]/main[1]/div["+i+"]/ngb-accordion[1]/div[1]/div[1]/div[1]/div[5]/div[1]/button[1]")).getText());
//		driver.findElement(By.xpath("/html[1]/body[1]/app-root[1]/app-debentures[1]/div[1]/div[1]/main[1]/div["+i+"]/ngb-accordion[1]/div[1]/div[1]/div[1]/div[5]/div[1]/button[1]")).click();
	//Thread.sleep(2000);
		 		//Publicar
driver.findElement(By.xpath("/html[1]/body[1]/app-root[1]/app-debentures[1]/div[1]/div[1]/main[1]/div["+i+"]/ngb-accordion[1]/div[1]/div[1]/div[1]/div[5]/div[1]/button[3]")).click();
WebDriverWait wait = new WebDriverWait(driver,20);
wait.until(ExpectedConditions.elementToBeClickable(btnConfirmaPublicacao));
	btnConfirmaPublicacao.click();
	js.executeScript(correto,CurvaX);
	takeSnapShot(driver, "./Evidencias/PublicarCurva"+CurvaX+".png");
	driver.navigate().refresh();
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("/html[1]/body[1]/app-root[1]/app-debentures[1]/div[1]/div[1]/main[1]/div["+i+"]/ngb-accordion[1]/div[1]/div[1]/div[1]/div[5]/div[1]/button[3]")));
		 				 	}
		 	else {System.out.println(CurvaX.getText());
		 		i++;}
		 				 }
}



}
