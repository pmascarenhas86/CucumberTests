package cucumberTests.pageObjects.Pricing;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import cucumberTests.pageObjects.Base;

public class ConfiguraCurvasPricingPO extends Base{

	public ConfiguraCurvasPricingPO(WebDriver driver) {
		super(driver);
		driver=this.driver;
		PageFactory.initElements(driver,this);
}

	@FindBy(name="calculationModel")
	public WebElement comboBoxModoCalculo;

	@FindBy(id="text_minValueCurve")
	public WebElement txtVlrMin;

	@FindBy(css="#text_penalty")
	public WebElement txtPenalty;

	@FindBy(css="#text_outlierStatistics")
	public WebElement txtOutlierStatistics;

	@FindBy(xpath="//body/app-root[1]/app-maintain-spread-curve[1]/form[1]/div[1]/div[2]/div[1]/div[1]/div[3]/select[1]")
	public WebElement comboBoxOutlierRound;

	@FindBy(id="text_upperBoundBeta")
	public WebElement txtUpperBoundBeta;

	@FindBy(id="text_upperBoundBetaCred")
	public WebElement txtUpperBoundBeta_Cred;

	@FindBy(id="text_upperBoundLambda")
	public WebElement txtUpperBoundLambda;

	@FindBy(id="text_lowerBoundBeta")
	public  WebElement txtLowerBoundBeta;

	@FindBy(id="text_lowerBoundBetaCred")
	public  WebElement txtLowerBoundBeta_Cred;

	@FindBy(id="text_lowerBoundLambda")
	public  WebElement txtLowerBoundLambda;

	@FindBy(id="text_addingCurve")
	public  WebElement comboboxAddingCurve;

	@FindBy(id="text_addingValue")
	public WebElement txtAddingValue;

	@FindBy(id="text_beta")
	public WebElement txtBeta;

	@FindBy(id="text_betaCred")
	public WebElement txtBeta_Cred;

	@FindBy(id="text_lambda")
	public WebElement txtLambda;

	@FindBy(xpath="/html/body/app-root/app-maintain-spread-curve/form/div/div[5]/div/div[2]/button")
	public WebElement botaoSalvar;

	@FindBy(xpath="//button[contains(text(),'Cancelar')]")
	public WebElement botaoCancelar;

	@FindBy(id="btn_confirm")
	public WebElement botaoConfirmaAlteracao;

	@FindBy(xpath="//div[@id='toast-container']")
	public WebElement popUpConfirmacao;


	public void defineValorComboBox(WebElement e,String string) throws InterruptedException
	{
		//WebElement dropdown = driver.findElement(By.name("calculationModel"));
		 e.findElement(By.xpath("//option[. = '"+string+"']")).click();
		//option[contains(text(),'2')]
		 Thread.sleep(2000);

	}

	public void escolherQuantidadeRodadas(String s) {
		this.comboBoxOutlierRound.findElement(By.xpath("//option[contains(text(),'"+s+"')]")).click();
	}

	public void escolherCurvaAdding(String s) {
		this.comboboxAddingCurve.findElement(By.xpath("//option[contains(text(),'"+s+"')]")).click();
	}

}
