package cucumberTests.pageObjects.Pricing;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import cucumberTests.pageObjects.Base;

public class LoginPagePricingPO extends cucumberTests.pageObjects.Base {

		public LoginPagePricingPO(WebDriver driver) {
		super(driver);
		driver=this.driver;
		PageFactory.initElements(driver,this);
}

@FindBy(css="#USER")
public WebElement txtUsuario;

@FindBy(css="#PASSWORD")
public WebElement txtSenha;

@FindBy(id="btnSubmit")
public WebElement btnLogar;

public GpsPricingHomePO realizarLoginPadrao(String URLdesejada) {
	driver.get(URLdesejada);
	txtUsuario.sendKeys(Base.LOGIN);
	txtSenha.sendKeys(Base.PASSWORD);
	try {
		Thread.sleep(2000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	btnLogar.click();
return new GpsPricingHomePO(driver);
	}

}
