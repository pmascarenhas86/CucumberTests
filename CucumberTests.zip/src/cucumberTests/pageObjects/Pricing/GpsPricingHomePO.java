package cucumberTests.pageObjects.Pricing;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import cucumberTests.pageObjects.Base;

public class GpsPricingHomePO extends Base{

	public GpsPricingHomePO(WebDriver driver) {
		super(driver);
		driver=this.driver;
		PageFactory.initElements(driver,this);
	}

	@FindBy(id="menu_configuration")
	public WebElement BarraMenus;

	@FindBy(xpath="//a[contains(text(),'Renda Fixa')]")
	public WebElement MenuRendaFixa;

	@FindBy(linkText="Manter PU Medio")
	private WebElement OpcaoManterPUMedio;

	@FindBy(linkText="Manter Prêmio")
	private WebElement OpcaoManterPremio;


	@FindBy(xpath="//a[contains(text(),'Curvas de Spread')]")
	public WebElement MenuCurvasSpread;
	//

	@FindBy(linkText="Analisar Curvas de Spread")
	public WebElement OpcaoAnalisarCurvasSpread;

	@FindBy(linkText="Manter Curvas de Spread")
	public WebElement OpcaoManterCurvasSpread;

	@FindBy(xpath="//a[contains(text(),'Ferramentas')]")
	public WebElement Menuferramentas;

	//@FindBy(xpath="//button[(text()='Sair')]")
	@FindBy(xpath="	//*[@id=\"mainNavbar\"]/ul[2]/li[3]/button")

	public WebElement botaoLogout;


	public void acessaMenuManterCurvas() {
		MenuCurvasSpread.click();
		OpcaoManterCurvasSpread.click();

	}

	public void AcessaAnalisarCurvas() {
					MenuCurvasSpread.click();
						OpcaoAnalisarCurvasSpread.click();
		}

	public PuMedioPO AcessaManterPUMedio(){
		MenuRendaFixa.click();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		OpcaoManterPUMedio.click();
		return new PuMedioPO(driver);
	}

	public PUManterPremio AcessaManterPremio() throws InterruptedException{
		MenuRendaFixa.click();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		OpcaoManterPremio.click();
		Thread.sleep(2000);
		return new PUManterPremio(driver);

	}

	public boolean Valida() {return visivel(BarraMenus);}



}
