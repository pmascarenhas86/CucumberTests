package cucumberTests.pageObjects.Pricing;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import cucumberTests.pageObjects.Base;

public class ManterCurvasNovaPO extends Base {

	public ManterCurvasNovaPO(WebDriver driver) {
		super(driver);
		this.driver=driver;
		PageFactory.initElements(driver,this);	}

	@FindBy(xpath="/html/body/app-root/app-list-spread-curve/div/div/main/ngx-datatable")
	public WebElement Tabela;


@FindBy(css="body > app-root > app-maintain-spread-curve > form")
public WebElement FomularioCurvas;

public void ConsultaTabela(String simboloCurva) {
	 boolean localizada=false;

		  List<WebElement> linha = Tabela.findElements(By.className("datatable-body-row"));
			 		 int i=1;
			 		while(!localizada && i<=linha.size()) {
			 			WebElement Curva = driver.findElement(By.xpath("/html/body/app-root/app-list-spread-curve/div/div/main/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper["+i+"]/datatable-body-row/div[2]/datatable-body-cell[1]/div"));
			 			System.out.println("Buscando "+ simboloCurva);
			 			System.out.println(Curva.getText());
			 			 	if(Curva.getText().equals(simboloCurva)) {
			 		localizada=true;
			 		     driver.findElement(By.xpath("/html/body/app-root/app-list-spread-curve/div/div/main/ngx-datatable/div/datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper["+i+"]/datatable-body-row/div[2]/datatable-body-cell[5]/div/button/i")).click();
			 		    			 		    			      }
			 	else {System.out.println(Curva.getText());
			 		i++;}
			 				 }
	 }}





	 /*
	  * APOS A EXECUCAO E2E, VALIDAR SE ESTE METODO NECESSARIO

	 public void ConfigurarCurvasPricingViaCSV()throws Exception {
		 String[] ColunaCSV;
			CSVReader arquivocsv = new CSVReaderBuilder(new FileReader("src/test/resources/datasets/PricingCurves.csv")).withSkipLines(1).build();
			while((ColunaCSV = arquivocsv.readNext())!=null) {
			String GRUPO = ColunaCSV[0];
			String TIPO= ColunaCSV[1];
			String SIMBOLO=ColunaCSV[2];
			String SPREAD=ColunaCSV[3];
			String INCENTIVADA=ColunaCSV[4];
			new Select(driver.findElement(By.id("groupCurve"))).selectByValue(GRUPO);
			new Select (driver.findElement(By.id("typeCurve"))).selectByIndex(Integer.parseInt(TIPO));
			driver.findElement(By.id("btnQuery")).click();

		String simboloCurva =SIMBOLO;
		System.out.println("Simbolo buscado:"+ simboloCurva);
		 WebElement tabelaCurvas = driver.findElement(By.xpath("/html/body/div[5]/div/form/div[5]/table"));
		List<WebElement> rows2 = tabelaCurvas.findElements(By.tagName("tr"));
		 System.out.println("Total de curvas disponiveis: " + rows2.size());
		 boolean localizada=false;
		 int i=1;
		 while(!localizada && i<rows2.size()) {
		 	WebElement Curva = driver.findElement(By.xpath("/html/body/div[5]/div/form/div[5]/table/tbody/tr["+i+"]/td[1]"));
		 	if(Curva.getText().equals(simboloCurva)) {
		 		System.out.println("Curva identificada na linha "+i+" "+simboloCurva);
		 		System.out.println("Valor localizado "+Curva.getText());
		 		localizada=true;
		 		     driver.findElement(By.xpath("/html/body/div[5]/div/form/div[5]/table/tbody/tr["+i+"]/td[3]/a")).click();
		      }
		 	else {i++;}
		 }
			if(driver.findElement(By.id("code")).isDisplayed()) {
			System.out.println("Acessada com sucesso");}
			else {System.out.println("Falha na configuracao");}
		if(INCENTIVADA=="S") {
			if(!driver.findElement(By.name("curve.encouraged")).isSelected()) {
				driver.findElement(By.name("curve.encouraged")).click();
		}
		}
		if(SPREAD=="S") {
			if(!driver.findElement(By.name("curve.spreadCurve")).isSelected()) {
				driver.findElement(By.name("curve.spreadCurve")).click();
		}
		}
		System.out.println("Curva " + SIMBOLO + "configurada!");
		//clicar(botaoSalvar);
				}}
	 /*
	  *
	  */








