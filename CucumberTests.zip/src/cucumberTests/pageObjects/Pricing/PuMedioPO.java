package cucumberTests.pageObjects.Pricing;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumberTests.pageObjects.Base;


public class PuMedioPO extends Base {

	public PuMedioPO(WebDriver driver) {
		super(driver);
		driver=this.driver;
		PageFactory.initElements(driver,this);
	}


	//public final By botaoImportar=By.xpath("/html/body/app-root/app-debentures-sheet/div/div/div/div/div/div/div[2]/button[1]");

	@FindBy(xpath="//button[contains(text(),'Importar')]")
	public WebElement botaoImportar;

	//public final By botaoExportar=By.xpath("/html/body/app-root/app-debentures-sheet/div/div/div/div/div/div/div[2]/button[2]");
	@FindBy(xpath="//button[contains(text(),'Exportar')]")
	public WebElement botaoExportar;

	public boolean Valida(WebElement we) {
		return we.isDisplayed();
		}


	@FindBy(xpath="/html/body/app-root/app-debentures-sheet/div/div/div/main/ngx-datatable")
	public WebElement TabelaPu;


	//@FindBy(xpath="//body/app-root[1]/app-debentures-sheet[1]/div[1]/div[1]/div[1]/main[1]/div[1]/div[2]/button[2]")
	@FindBy(xpath="//body/app-root[1]/app-debentures-sheet[1]/div[1]/div[1]/div[1]/main[1]/div[1]/div[2]/button[2]")
	public WebElement botaoSalvarOuPublicar;


	@FindBy(id="toast-container")
	public WebElement mensagemSucessoPU;

	 	public void EnviaPUMedio(String CaminhoDoArquivoCompleto) {
		WebElement ImportFile= driver.findElement(By.id("fileUpload"));
		ImportFile.sendKeys(CaminhoDoArquivoCompleto);
		Valida(TabelaPu);
			}


	 	public void importarSalvarEPublicarPuMedio() {
	 		botaoSalvarOuPublicar.click();
	 		mensagemSucessoPU.click();
	 		WebDriverWait wait = new WebDriverWait(driver,20);
	 		wait.until(ExpectedConditions.invisibilityOf(mensagemSucessoPU));
	 		System.out.println(botaoSalvarOuPublicar.getText().toString());
	 		botaoSalvarOuPublicar.click();
	 		mensagemSucessoPU.click();
	 	}



}
