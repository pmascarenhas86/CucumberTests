package cucumberTests.pageObjects.Clearing;

import java.io.FileReader;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;

import cucumberTests.pageObjects.Base;


public class ManterCurvasPO extends Base {

	public ManterCurvasPO(WebDriver driver) {
		super(driver);
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}

	//Declara Objetos
	@FindBy(id="item")
	public WebElement tabelaSimbolos;

	@FindBy(id="groupCurve")
	public Select comboBoxGrupo;

	@FindBy(id="typeCurve")
	public Select comboBoxTipo;

	@FindBy(id="code")
	public WebElement codigoCurva;

	@FindBy(id="btnQuery")
	public WebElement BotaoConfirmaCombos;
	//public final  WebElement chkIncentivada = driver.findElement(By.name("curve.encouraged"));
	//public final  WebElement chkSpread = driver.findElement(By.name("curve.spreadCurve"));

	@FindBy(id="save")
	public WebElement botaoSalvar;

	//Fim Objetos

		//Inicio Metodos

	 public void BuscaCurvaTabela(String simboloCurva) throws Exception {
	WebElement tabelaCurvas = driver.findElement(By.xpath("/html/body/div[5]/div/form/div[5]/table"));
	 List<WebElement> linhas = tabelaCurvas.findElements(By.tagName("tr"));
	 boolean localizada=false;
		 int i=1;
		 while(!localizada && i<linhas.size()) {
		 	WebElement Curva = driver.findElement(By.xpath("/html/body/div[5]/div/form/div[5]/table/tbody/tr["+i+"]/td[1]"));
		 	if(Curva.getText().equals(simboloCurva)) {
		 		System.out.println("Curva Localizada");
		 		localizada=true;
		 		     driver.findElement(By.xpath("/html/body/div[5]/div/form/div[5]/table/tbody/tr["+i+"]/td[3]/a")).click();
		      }
		 	else {i++;}
		 }
	 }


	 public void ManterCurvasViaCSV()throws Exception {

		String[] ColunaCSV;
			CSVReader arquivocsv = new CSVReaderBuilder(new FileReader("src/test/resources/datasets/Curves.csv")).withSkipLines(1).build();
			while((ColunaCSV = arquivocsv.readNext())!=null) {
			String GRUPO = ColunaCSV[0];
			String TIPO= ColunaCSV[1];
			String SIMBOLO=ColunaCSV[2];
			String SPREAD=ColunaCSV[3];
			String INCENTIVADA=ColunaCSV[4];
			//Select comboBoxGrupo = new Select(driver.findElement(By.id("groupCurve")));
			Select comboBoxGrupo = new Select(driver.findElement(By.id("groupCurve")));
			comboBoxGrupo.selectByValue(GRUPO);
			Select comboBoxTipo= new Select (driver.findElement(By.id("typeCurve")));
			comboBoxTipo.selectByIndex(Integer.parseInt(TIPO));
			BotaoConfirmaCombos.click();

		String simboloCurva =SIMBOLO;
		System.out.println("Simbolo buscado:"+ simboloCurva);
		 WebElement tabelaCurvas = driver.findElement(By.xpath("/html/body/div[5]/div/form/div[5]/table"));
		List<WebElement> rows2 = tabelaCurvas.findElements(By.tagName("tr"));
		 System.out.println("Total de curvas disponiveis: " + rows2.size());
		 boolean localizada=false;
		 int i=1;
		 while(!localizada && i<rows2.size()) {
		 	WebElement Curva = driver.findElement(By.xpath("/html/body/div[5]/div/form/div[5]/table/tbody/tr["+i+"]/td[1]"));
		 	if(Curva.getText().equals(simboloCurva)) {
		 		System.out.println("Curva identificada na linha "+i+" "+simboloCurva);
		 		System.out.println("Valor localizado "+Curva.getText());
		 		localizada=true;
		 		     driver.findElement(By.xpath("/html/body/div[5]/div/form/div[5]/table/tbody/tr["+i+"]/td[3]/a")).click();

		 		    if(driver.findElement(By.id("code")).isDisplayed()) {
		 				System.out.println("Acessada com sucesso");}
		 				else {System.out.println("Falha na configuracao");}

		 		    if(INCENTIVADA=="S") {
		 				if(!driver.findElement(By.name("curve.encouraged")).isSelected()) {
		 					driver.findElement(By.name("curve.encouraged")).click();
		 			}
		 			}
		 			if(SPREAD=="S") {
		 				if(!driver.findElement(By.name("curve.spreadCurve")).isSelected()) {
		 					driver.findElement(By.name("curve.spreadCurve")).click();
		 			}
		 			}
		 			System.out.println("Curva " + SIMBOLO + " configurada!");
		 			botaoSalvar.click();
		 		}
		 	else {i++;}
		 }}}

		public boolean Valida() {return visivel(tabelaSimbolos);}

		}
