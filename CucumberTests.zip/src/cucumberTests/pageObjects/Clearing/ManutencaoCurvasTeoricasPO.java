package cucumberTests.pageObjects.Clearing;

import java.io.FileReader;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;


public class ManutencaoCurvasTeoricasPO extends cucumberTests.pageObjects.Base {
	JavascriptExecutor js;


	 public ManutencaoCurvasTeoricasPO(WebDriver driver) {
		 super(driver);
			this.driver=driver;
			this.js = (JavascriptExecutor) this.driver;
			PageFactory.initElements(driver,this);
		}


	//Declara Objetos


	public Select comboBoxGeracao 	= new Select(driver.findElement(By.id("idGeneration")));
	public Select comboBoxStatus	= new Select(driver.findElement(By.id("idStatus")));
	public Select comboBoxGrupo 	= new Select(driver.findElement(By.id("groupDescription")));
	public Select comboBoxReferencia= new Select(driver.findElement(By.cssSelector("#idReference")));

	@FindBy(id="idReference")
	public WebElement cboReferencia;

	@FindBy(id="idCurve")
	public WebElement listagemCurvas;

	@FindBy(id="btnQuery")
	public WebElement botaoConfirmaComboboxes;

	@FindBy(id="save")
	public WebElement btnSalvar;

	@FindBy(id="resulTable")
	public WebElement tabelaResultados;

	@FindBy(xpath="//form[@id='maintainCurvesFBO']")
	public WebElement FormTabelas;

	//Fim Objetos

		//Inicio Metodos


	public void ManterCurvasTeoricasViaCSV()throws Exception {
	String[] ColunaCSV;
	CSVReader arquivocsv = new CSVReaderBuilder(new FileReader("src/test/resources/datasets/CurvesDapDpl.csv")).withSkipLines(1).build();
	while((ColunaCSV = arquivocsv.readNext())!=null) {
			String GERACAO = ColunaCSV[0];
			String STATUS= ColunaCSV[1];
			String GRUPO=ColunaCSV[2];
			String CURVA=ColunaCSV[3];
			String REFERENCIA=ColunaCSV[4];
			System.out.print(ColunaCSV);
			comboBoxGeracao.selectByVisibleText(GERACAO);
			comboBoxStatus.selectByVisibleText(STATUS);
			comboBoxGrupo.selectByVisibleText(GRUPO);
			Thread.sleep(3000);
			new Select(listagemCurvas).selectByVisibleText(CURVA);
			new Select(cboReferencia).selectByVisibleText(REFERENCIA);

}
		botaoConfirmaComboboxes.click();
				btnSalvar.click();
				}

	public void ValidaCalculos(String Curva) {
		js.executeScript(correto,FormTabelas);
	//takeSnapShot(driver, "./Evidencias/ValidacaoCalculoCurva"+Curva+".png");
	}
}