package cucumberTests.pageObjects.Clearing;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;


public class RendaFixaBalcaoPO extends cucumberTests.pageObjects.Base{
	JavascriptExecutor js;


	public RendaFixaBalcaoPO(WebDriver driver) {
		super(driver);
		this.driver=driver;
		this.js = (JavascriptExecutor) this.driver;
		PageFactory.initElements(driver,this);
	}

	@FindBy(id="searchDeb")
	public WebElement inputDebenture;

	@FindBy(id="statusDebenture")
	public WebElement comboboxStatusDebenture;

	@FindBy(id="criteria.published1")
	public WebElement chkPublicado;

	@FindBy(id="criteria.withoutPublish1")
	public WebElement chkNaoPublicado;

	@FindBy(id="criteria.updatedAfterCalculation1")
	public WebElement chkPosCalculo;

	@FindBy(id="criteria.withoutCalculation1")
	public WebElement chkPdtCalculo;

	@FindBy(id="btnQuery")
	public WebElement btnConsulta;


	@FindBy(xpath="/html/body/div[5]/div/form/div/div[1]/table/tbody/tr/td[2]/table/tbody/tr[3]/td/input")
	public WebElement btnConsultaSimples;

	@FindBy(xpath="/html/body/div[5]/div/form/div/div[1]/table/tbody/tr/td[3]/table/tbody/tr/td/input")
	public WebElement btnPublicaSimples;

	@FindBy(xpath="/html/body/div[5]/div/form/table/tbody/tr/td[1]/input")
	public WebElement btnCalcularTodos;

	@FindBy(xpath="/html/body/div[5]/div/form/table/tbody/tr/td[2]/input")
	public WebElement btnPublicarTodos;

	@FindBy(id="premium")
	public WebElement txtpremio;

	@FindBy(id="amount")
	public WebElement txtmontante;

	@FindBy(id="recoveryRate")
	public WebElement txRecuperacao;

	@FindBy(id="incorporatedRate")
	public WebElement txtjurosIncT0;

	@FindBy(id="rateCalculationLowerBound")
	public WebElement txMinima;

	@FindBy(id="formulas")
	public Select formula;

	@FindBy(id="publishPrecision")
	public WebElement txtdecimalPub;

	@FindBy(id="pricingRatingrate")
	public WebElement txtratingGPS;

	@FindBy(id="CalculationUpperBound")
	public WebElement txMaxima;

	@FindBy(id="indicatorReferenceValue")
	public WebElement txtn0;

	@FindBy(id="chkCalculateIndicator")
	public WebElement chkCalcular;

	@FindBy(id="chkPublishIndicator")
	public WebElement chkPublicar;

	@FindBy(id="btnSave")
	public WebElement btnSalvar;

	@FindBy(id="btnCancelar")
	public WebElement btnCancelar;

	@FindBy(id="observation")
	public WebElement txtObservacoes;

	@FindBy(id="fixedincometable")
	public WebElement tabelaDebenturesResult;



public void ConfiguraDebenture(String Premio, String Montante, String TxRec, String JIncT0, String TxMin, String Decimal, String Rating, String TxMax, String N0, String Observacoes) {
	this.digitar(Premio, txtpremio);
	this.digitar(Montante, txtmontante);
	this.digitar(TxRec, txRecuperacao);
	this.digitar(JIncT0, txtjurosIncT0);
	this.digitar(TxMin, txMinima);
	this.digitar(Decimal, txtdecimalPub);
	this.digitar(Rating, txtratingGPS);
	this.digitar(TxMax, txMaxima);
	this.digitar(N0, txtn0);
	this.digitar(Observacoes,txtObservacoes);
}

public void Checks() {
chkCalcular.click();
chkPublicar.click();
	}

public void coletaEvidenciasCalculo(String Curva) {
	assert(tabelaDebenturesResult.isDisplayed());
	js.executeScript(correto,tabelaDebenturesResult);
	takeSnapShot(driver, "./Evidencias/Publicacao"+Curva+".png");


}


}



