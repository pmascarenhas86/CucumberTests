package cucumberTests.pageObjects.Clearing;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import cucumberTests.dataProvider.ConfigFileReader;
import cucumberTests.pageObjects.Base;

public class LoginPageClearingPO extends Base {
	JavascriptExecutor js;


	public LoginPageClearingPO(WebDriver driver) {
		super(driver);
		driver=this.driver;
	    this.js = (JavascriptExecutor) this.driver;
		PageFactory.initElements(driver,this);
}




	@FindBy(css="#USER")
	public WebElement campoUsuario;

	@FindBy(css="#PASSWORD")
	public WebElement campoSenha;

	@FindBy(id="btnSubmit")
	public WebElement botaoLogar;



	public  GpsClearingHomePO realizarLoginPadrao(String URLdesejada) throws Exception {
		driver.get(URLdesejada);
		campoUsuario.sendKeys(ConfigFileReader.getApplicationUser());
        js.executeScript(correto,campoUsuario);
        js.executeScript(correto,campoSenha);
        campoSenha.sendKeys(ConfigFileReader.getApplicationUserPass());
        js.executeScript(correto,botaoLogar);
        takeSnapShot(driver, "./Evidencias/Debentures/Clearing/realizarLoginPadrao.png");
		botaoLogar.click();
		return new GpsClearingHomePO(driver);


	}


}
