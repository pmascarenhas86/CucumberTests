package cucumberTests.pageObjects.Clearing;


import java.io.File;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ImportacaoDeTaxasPO extends cucumberTests.pageObjects.Base{
	JavascriptExecutor js;

	public ImportacaoDeTaxasPO(WebDriver driver) {
		super(driver);
		this.driver=driver;
		this.js = (JavascriptExecutor) this.driver;
		PageFactory.initElements(driver,this);
	}



	@FindBy(xpath="//input[@id='injectorEngine4']")
	public WebElement inputCurvas;

	@FindBy(xpath="//input[@id='injectorEngine5']")
	public WebElement inputIndicadores;


	@FindBy(xpath="//input[@id='importPublish']")
	public WebElement inputImportarEPublicar;

	@FindBy(xpath="//input[@id='file_upload']")
	public WebElement inputFile;

	@FindBy(xpath="//button[contains(text(),'Enviar')]")
	public WebElement botaoEnviar;

	@FindBy(id="successMessage")
	public WebElement mensagemSucesso;

	@FindBy(xpath="//a[contains(text(),'Voltar')]")
	public WebElement botaoVoltar;

	public void importarPlanilhaDeCurvas() {
		inputCurvas.click();
		inputImportarEPublicar.click();
		File arquivoCurvas = new File(new File("src/test/resources/datasets/InsumoCurvas.xls").getAbsolutePath());
		inputFile.sendKeys(arquivoCurvas.toString());
		botaoEnviar.click();
		esperarPeloElemento(3,botaoVoltar);
		botaoVoltar.click();

	}

	public void importarPlanilhaDeIndicadores() {
		inputIndicadores.click();
		inputImportarEPublicar.click();
		File arquivoIndicadoresEconomicos = new File(new File("src/test/resources/datasets/InsumoIndicadoresEconomicos.xls").getAbsolutePath());
		inputFile.sendKeys(arquivoIndicadoresEconomicos.toString());
		botaoEnviar.click();
		esperarPeloElemento(3,botaoVoltar);
		botaoVoltar.click();
	}

 	public void EnviaArquivoInsumo(String CaminhoDoArquivoCurvasCompleto) {
	inputFile.sendKeys(CaminhoDoArquivoCurvasCompleto);
}


}
