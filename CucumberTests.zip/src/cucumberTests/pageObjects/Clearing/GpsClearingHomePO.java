package cucumberTests.pageObjects.Clearing;


import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import cucumberTests.dataProvider.ConfigFileReader;


public class GpsClearingHomePO extends cucumberTests.pageObjects.Base {
	JavascriptExecutor js;
	ConfigFileReader configFileReader;

	public GpsClearingHomePO(WebDriver driver) {
		super(driver);
		this.js = (JavascriptExecutor) this.driver;
		PageFactory.initElements(driver,this);
		configFileReader= new ConfigFileReader();

	}



	//MapeamentoMenu
	//MENUCALENDARIO
	@FindBy(id="calendarId")
	private WebElement  MenuCalendario;

	//MenuCaptura
	@FindBy(id="captureId")
	private WebElement MenuCaptura;

	// MenuIndicadores
	@FindBy(id="indicatorsId")
	private WebElement MenuIndicadore;


	//MenuAjustes
	@FindBy(id="adjustsId")
	private WebElement MenuAjustes;


	//MenuCurvas
	@FindBy(linkText="Curvas")
	private WebElement MenuCurvas;


	@FindBy(id="consultInflationId")
	private WebElement OpcaoConsultarInflacao;

	@FindBy(id="maturityId")
	private WebElement OpcaoPrazos;

	@FindBy(id="curveInformantId")
	private WebElement OpcaoColetarCurvaInflacao;

	@FindBy(id="maintainId")
	private WebElement OpcaoManterCurvas;

	@FindBy(id="maintainTheoreticalId")
	private WebElement OpcaoManterCurvasTeoricas;

	@FindBy(id="importTheoreticalId")
	private WebElement OpcaoImportacaoCurvasTeoricas;

	//MenuVolatilidade
	@FindBy(id="volatilityId")
	private WebElement MenuVolatilidade;


	//MenuRendaFixa]
	@FindBy(xpath="//a[@id='FixedIncomeId']")
	private WebElement MenuRendaFixa;

	@FindBy(id="maintainNoMeFixedIncomeId")
	public WebElement OpcaoManterRendaFixaBalcao;

//Link de LogOut
	@FindBy(css="#logouturl")
	public WebElement botaoLogout;

	//Menu Ferramentas
	@FindBy(linkText="Ferramentas")
	private WebElement MenuFerramentas;

	@FindBy(id="toolsInjector")
	private WebElement OpcaoPlanilhaInjetora;




	public boolean Valida() {
		return MenuCurvas.isDisplayed();
		}

	public GpsClearingHomePO AcessaManterCurvas() throws Exception {
		js.executeScript(correto,MenuCurvas);
		MenuCurvas.click();
		js.executeScript(correto,OpcaoManterCurvas);
		takeSnapShot(driver, "./Evidencias/Debentures/Clearing/AcessaManterCurvas.png");
		OpcaoManterCurvas.click();
		return new GpsClearingHomePO(driver);
	}


	public GpsClearingHomePO AcessaImportacaoCurvasTeoricas(){
	MenuCurvas.click();
	OpcaoImportacaoCurvasTeoricas.click();
	return new GpsClearingHomePO(driver);
}


	public RendaFixaBalcaoPO AcessaManterRendaFixaBalcao() {
	MenuRendaFixa.click();
OpcaoManterRendaFixaBalcao.click();
		return new RendaFixaBalcaoPO(driver);
	}

	public ManutencaoCurvasTeoricasPO AcessaManutencaoCurvasTeoricas() throws InterruptedException {
	MenuCurvas.click();
	OpcaoManterCurvasTeoricas.click();
	return new ManutencaoCurvasTeoricasPO(driver);
}

	public ImportacaoDeTaxasPO AcessaFerramentasImportarInsumos() {
	MenuFerramentas.click();
	OpcaoPlanilhaInjetora.click();
	return new ImportacaoDeTaxasPO(driver);}

	public void encerraSessao() {
	botaoLogout.click();
	}


}
